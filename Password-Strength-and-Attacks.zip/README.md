Password Strength and Attacks – Task 6

This project focuses on creating, testing, and evaluating different types of passwords to understand what makes a password strong or weak. It also includes common methods attackers use to break passwords.

Overview

The task involves:
1. Creating passwords with different lengths and complexities
2. Checking how strong or weak those passwords are using strength-checking tools
3. Learning best practices for building strong passwords
4. Understanding common password attack methods

Password Test Results

Riya@2003              - Weak (1 hour to crack)  
Riya963852741          - Strong (1 month to crack)  
Riya@0336              - Medium (5 days to crack)  
123456789              - Very Weak (13 seconds to crack)  
Riya@9693725405        - Very Strong (1000 years to crack)

Best Practices for Strong Passwords

- Use 12 to 16 characters or more
- Include uppercase, lowercase, numbers, and symbols
- Avoid names, birth dates, or common words
- Do not reuse old passwords
- Try using passphrases like Green!Tiger@Moon77
- Use a password manager to save and create complex passwords

Tips Learned

- Longer passwords are harder to crack
- Adding symbols can improve security a lot
- Common-looking passwords can still be risky
- Random patterns are better than dictionary words

Common Password Attack Methods

1. Brute Force: Tries all combinations until it finds the correct one (slow but sure).
2. Dictionary Attack: Uses a list of common passwords or words.
3. Phishing: Tricks users into giving away passwords through fake websites or messages.

Password Complexity and Security

A complex password is more secure. The more unique characters and length it has, the harder it becomes to crack. Simple passwords like "123456" are very easy to break, but a password like "R!ya@9693725405" can take centuries to guess using automated tools.

File Structure

Password-Strength-and-Attacks/
├── README.md
├── task6_password_report.pdf
├── samples/
│   └── tested_passwords.txt
├── attacks/
│   └── attack_methods.txt

Stay safe by using smart passwords!
